import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Car, 
  Wrench, 
  Store,
  Users,
  FileText,
  LogOut,
  Shield,
  Settings
} from 'lucide-react';
import { useAuth } from '../../store/AuthContext';
import { cn } from '../../utils/cn';

interface NavItem {
  to: string;
  icon: React.ReactNode;
  label: string;
}

export function Sidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  const isManager = user?.role === 'manager';
  
  const managerNav: NavItem[] = [
    { to: '/operations/dashboard', icon: <LayoutDashboard className="w-5 h-5" />, label: 'Dashboard' },
    { to: '/operations/intake', icon: <Car className="w-5 h-5" />, label: 'Vehicle Intake' },
    { to: '/operations/garage', icon: <Wrench className="w-5 h-5" />, label: 'Garage Workshop' },
    { to: '/operations/stand', icon: <Store className="w-5 h-5" />, label: 'Car Stand' },
  ];
  
  const managementNav: NavItem[] = [
    { to: '/executive/overview', icon: <LayoutDashboard className="w-5 h-5" />, label: 'Overview' },
    { to: '/executive/audit', icon: <FileText className="w-5 h-5" />, label: 'Audit Trail' },
    { to: '/executive/users', icon: <Users className="w-5 h-5" />, label: 'User Management' },
  ];
  
  const navItems = isManager ? managerNav : managementNav;
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 text-white flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-lg">Project Titan</h1>
            <p className="text-xs text-slate-400">
              {isManager ? 'Operations Hub' : 'Executive Hub'}
            </p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => cn(
              'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
              isActive 
                ? 'bg-blue-600 text-white' 
                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
            )}
          >
            {item.icon}
            <span className="font-medium">{item.label}</span>
          </NavLink>
        ))}
      </nav>
      
      {/* User info & Logout */}
      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center">
            <Shield className="w-5 h-5 text-slate-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{user?.email}</p>
            <p className="text-xs text-slate-400 capitalize">{user?.role}</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-red-500/10 hover:text-red-400 transition-all duration-200"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
