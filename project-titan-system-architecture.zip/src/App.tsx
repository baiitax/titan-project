import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './store/AuthContext';
import { DataProvider, useData } from './store/DataContext';
import { MainLayout } from './components/layout/MainLayout';
import { LoginPage } from './pages/LoginPage';
import { OperationsDashboard } from './pages/operations/OperationsDashboard';
import { VehicleIntake } from './pages/operations/VehicleIntake';
import { GarageWorkshop } from './pages/operations/GarageWorkshop';
import { GarageJobCard } from './pages/operations/GarageJobCard';
import { CarStand } from './pages/operations/CarStand';
import { ExecutiveOverview } from './pages/executive/ExecutiveOverview';
import { AuditTrail } from './pages/executive/AuditTrail';
import { UserManagement } from './pages/executive/UserManagement';
import { useEffect } from 'react';

// Component to sync auth user ID with data context
function AuthDataSync({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const { setCurrentUserId } = useData();
  
  useEffect(() => {
    setCurrentUserId(user?.id || null);
  }, [user, setCurrentUserId]);
  
  return <>{children}</>;
}

// Protected route wrapper for role-based access
function ProtectedRoute({ 
  children, 
  allowedRole 
}: { 
  children: React.ReactNode; 
  allowedRole: 'manager' | 'management';
}) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (user.role !== allowedRole) {
    // Redirect to appropriate dashboard based on role
    const redirectPath = user.role === 'manager' 
      ? '/operations/dashboard' 
      : '/executive/overview';
    return <Navigate to={redirectPath} replace />;
  }
  
  return <>{children}</>;
}

// Root redirect based on auth state
function RootRedirect() {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  const redirectPath = user.role === 'manager' 
    ? '/operations/dashboard' 
    : '/executive/overview';
  
  return <Navigate to={redirectPath} replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <DataProvider>
          <AuthDataSync>
            <Routes>
              {/* Public Route */}
              <Route path="/login" element={<LoginPage />} />
              
              {/* Root Redirect */}
              <Route path="/" element={<RootRedirect />} />
              
              {/* Manager/Operations Routes */}
              <Route
                path="/operations"
                element={
                  <ProtectedRoute allowedRole="manager">
                    <MainLayout />
                  </ProtectedRoute>
                }
              >
                <Route index element={<Navigate to="dashboard" replace />} />
                <Route path="dashboard" element={<OperationsDashboard />} />
                <Route path="intake" element={<VehicleIntake />} />
                <Route path="garage" element={<GarageWorkshop />} />
                <Route path="garage/:id" element={<GarageJobCard />} />
                <Route path="stand" element={<CarStand />} />
              </Route>
              
              {/* Management/Executive Routes */}
              <Route
                path="/executive"
                element={
                  <ProtectedRoute allowedRole="management">
                    <MainLayout />
                  </ProtectedRoute>
                }
              >
                <Route index element={<Navigate to="overview" replace />} />
                <Route path="overview" element={<ExecutiveOverview />} />
                <Route path="audit" element={<AuditTrail />} />
                <Route path="users" element={<UserManagement />} />
              </Route>
              
              {/* Catch-all redirect */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </AuthDataSync>
        </DataProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
