// Enums matching database schema
export type UserRole = 'manager' | 'management';

export type VehicleState = 
  | 'Under Maintenance' 
  | 'Pending Transfer' 
  | 'Active on Stand' 
  | 'Settled & Exited' 
  | 'Archived (Paid)' 
  | 'Archived (Closed)';

export type GarageStatus = 'active' | 'paid' | 'deferred';

export type StandStatus = 'active' | 'settled';

// Database models
export interface Profile {
  id: string;
  email: string;
  role: UserRole;
  updated_at: string;
}

export interface Vehicle {
  id: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  engine_number: string;
  current_mileage: number;
  owner_name: string;
  owner_phone: string;
  owner_email: string;
  owner_national_id: string;
  status: VehicleState;
  created_at: string;
  updated_at: string;
}

export interface GarageJob {
  id: string;
  vehicle_id: string;
  parts_cost: number;
  labor_hours: number;
  hourly_rate: number;
  total_bill: number;
  status: GarageStatus;
  check_in_timestamp: string;
  closed_at: string | null;
}

export interface CarStandInventory {
  id: string;
  vehicle_id: string;
  fixed_stand_fee: number;
  target_list_price: number;
  final_sale_price: number;
  final_payout: number;
  status: StandStatus;
  entered_at: string;
  exited_at: string | null;
}

export interface AuditTrail {
  id: string;
  timestamp: string;
  user_id: string;
  action_type: string;
  table_name: string;
  record_id: string;
  old_value: Record<string, unknown> | null;
  new_value: Record<string, unknown> | null;
}

// Joined types for UI
export interface GarageJobWithVehicle extends GarageJob {
  vehicle: Vehicle;
}

export interface CarStandWithVehicle extends CarStandInventory {
  vehicle: Vehicle;
  garage_job?: GarageJob;
}

// Form types
export interface VehicleIntakeForm {
  vin: string;
  make: string;
  model: string;
  year: number;
  engine_number: string;
  current_mileage: number;
  owner_name: string;
  owner_phone: string;
  owner_email: string;
  owner_national_id: string;
}

export interface StandAcceptForm {
  fixed_stand_fee: number;
  target_list_price: number;
}

export interface SaleExecuteForm {
  final_sale_price: number;
}
