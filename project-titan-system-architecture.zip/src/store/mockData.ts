import { v4 as uuidv4 } from 'uuid';
import type { Profile, Vehicle, GarageJob, CarStandInventory, AuditTrail } from '../types';

// Generate unique IDs for demo data
const vehicleId1 = uuidv4();
const vehicleId2 = uuidv4();
const vehicleId3 = uuidv4();
const vehicleId4 = uuidv4();
const vehicleId5 = uuidv4();

const userId1 = uuidv4();
const userId2 = uuidv4();
const userId3 = uuidv4();

// Initial mock data
export const initialProfiles: Profile[] = [
  {
    id: userId1,
    email: 'manager@titan.com',
    role: 'manager',
    updated_at: new Date().toISOString(),
  },
  {
    id: userId2,
    email: 'admin@titan.com',
    role: 'management',
    updated_at: new Date().toISOString(),
  },
  {
    id: userId3,
    email: 'staff@titan.com',
    role: 'manager',
    updated_at: new Date().toISOString(),
  },
];

export const initialVehicles: Vehicle[] = [
  {
    id: vehicleId1,
    vin: '1HGBH41JXMN109186',
    make: 'Toyota',
    model: 'Camry',
    year: 2021,
    engine_number: 'EN123456789',
    current_mileage: 45000,
    owner_name: 'John Smith',
    owner_phone: '+1-555-0101',
    owner_email: 'john.smith@email.com',
    owner_national_id: 'ID-12345678',
    status: 'Under Maintenance',
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: vehicleId2,
    vin: '2T1BURHE5JC123456',
    make: 'Honda',
    model: 'Accord',
    year: 2020,
    engine_number: 'EN987654321',
    current_mileage: 62000,
    owner_name: 'Sarah Johnson',
    owner_phone: '+1-555-0102',
    owner_email: 'sarah.j@email.com',
    owner_national_id: 'ID-87654321',
    status: 'Pending Transfer',
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: vehicleId3,
    vin: '3FA6P0H74HR123789',
    make: 'Ford',
    model: 'Fusion',
    year: 2019,
    engine_number: 'EN456789123',
    current_mileage: 78000,
    owner_name: 'Michael Brown',
    owner_phone: '+1-555-0103',
    owner_email: 'michael.b@email.com',
    owner_national_id: 'ID-11223344',
    status: 'Active on Stand',
    created_at: new Date(Date.now() - 86400000 * 7).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: vehicleId4,
    vin: 'WVWZZZ3CZWE123456',
    make: 'Volkswagen',
    model: 'Passat',
    year: 2022,
    engine_number: 'EN789123456',
    current_mileage: 28000,
    owner_name: 'Emily Davis',
    owner_phone: '+1-555-0104',
    owner_email: 'emily.d@email.com',
    owner_national_id: 'ID-44332211',
    status: 'Archived (Paid)',
    created_at: new Date(Date.now() - 86400000 * 14).toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: vehicleId5,
    vin: 'JM1BL1SF5A1123456',
    make: 'Mazda',
    model: 'Mazda3',
    year: 2021,
    engine_number: 'EN321654987',
    current_mileage: 35000,
    owner_name: 'Robert Wilson',
    owner_phone: '+1-555-0105',
    owner_email: 'robert.w@email.com',
    owner_national_id: 'ID-55667788',
    status: 'Settled & Exited',
    created_at: new Date(Date.now() - 86400000 * 10).toISOString(),
    updated_at: new Date().toISOString(),
  },
];

export const initialGarageJobs: GarageJob[] = [
  {
    id: uuidv4(),
    vehicle_id: vehicleId1,
    parts_cost: 450.00,
    labor_hours: 6.5,
    hourly_rate: 75.00,
    total_bill: 450.00 + (6.5 * 75.00),
    status: 'active',
    check_in_timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
    closed_at: null,
  },
  {
    id: uuidv4(),
    vehicle_id: vehicleId2,
    parts_cost: 1200.00,
    labor_hours: 12.0,
    hourly_rate: 75.00,
    total_bill: 1200.00 + (12.0 * 75.00),
    status: 'deferred',
    check_in_timestamp: new Date(Date.now() - 86400000 * 5).toISOString(),
    closed_at: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: uuidv4(),
    vehicle_id: vehicleId3,
    parts_cost: 850.00,
    labor_hours: 8.0,
    hourly_rate: 75.00,
    total_bill: 850.00 + (8.0 * 75.00),
    status: 'deferred',
    check_in_timestamp: new Date(Date.now() - 86400000 * 7).toISOString(),
    closed_at: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
  {
    id: uuidv4(),
    vehicle_id: vehicleId4,
    parts_cost: 320.00,
    labor_hours: 3.5,
    hourly_rate: 75.00,
    total_bill: 320.00 + (3.5 * 75.00),
    status: 'paid',
    check_in_timestamp: new Date(Date.now() - 86400000 * 14).toISOString(),
    closed_at: new Date(Date.now() - 86400000 * 12).toISOString(),
  },
  {
    id: uuidv4(),
    vehicle_id: vehicleId5,
    parts_cost: 550.00,
    labor_hours: 5.0,
    hourly_rate: 75.00,
    total_bill: 550.00 + (5.0 * 75.00),
    status: 'deferred',
    check_in_timestamp: new Date(Date.now() - 86400000 * 10).toISOString(),
    closed_at: new Date(Date.now() - 86400000 * 8).toISOString(),
  },
];

export const initialCarStandInventory: CarStandInventory[] = [
  {
    id: uuidv4(),
    vehicle_id: vehicleId3,
    fixed_stand_fee: 500.00,
    target_list_price: 18500.00,
    final_sale_price: 0,
    final_payout: 0,
    status: 'active',
    entered_at: new Date(Date.now() - 86400000 * 4).toISOString(),
    exited_at: null,
  },
  {
    id: uuidv4(),
    vehicle_id: vehicleId5,
    fixed_stand_fee: 450.00,
    target_list_price: 16000.00,
    final_sale_price: 15500.00,
    final_payout: 15500.00 - 450.00 - (550.00 + 5.0 * 75.00),
    status: 'settled',
    entered_at: new Date(Date.now() - 86400000 * 8).toISOString(),
    exited_at: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
];

export const initialAuditTrail: AuditTrail[] = [
  {
    id: uuidv4(),
    timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
    user_id: userId1,
    action_type: 'INSERT',
    table_name: 'vehicles',
    record_id: vehicleId1,
    old_value: null,
    new_value: { vin: '1HGBH41JXMN109186', make: 'Toyota', model: 'Camry' },
  },
  {
    id: uuidv4(),
    timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
    user_id: userId1,
    action_type: 'UPDATE',
    table_name: 'vehicles',
    record_id: vehicleId2,
    old_value: { status: 'Under Maintenance' },
    new_value: { status: 'Pending Transfer' },
  },
  {
    id: uuidv4(),
    timestamp: new Date(Date.now() - 86400000 * 1).toISOString(),
    user_id: userId2,
    action_type: 'UPDATE',
    table_name: 'car_stand_inventory',
    record_id: vehicleId5,
    old_value: { status: 'active' },
    new_value: { status: 'settled', final_sale_price: 15500.00 },
  },
];

export { userId1, userId2, userId3 };
