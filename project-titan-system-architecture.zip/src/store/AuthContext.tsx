import React, { createContext, useContext, useState, useEffect } from 'react';
import type { UserRole } from '../types';
import { initialProfiles } from './mockData';

interface AuthUser {
  id: string;
  email: string;
  role: UserRole;
}

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Demo credentials mapping
const demoCredentials: Record<string, { password: string; profileIndex: number }> = {
  'manager@titan.com': { password: 'manager123', profileIndex: 0 },
  'admin@titan.com': { password: 'admin123', profileIndex: 1 },
  'staff@titan.com': { password: 'staff123', profileIndex: 2 },
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const stored = localStorage.getItem('titan_session');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setUser(parsed);
      } catch {
        localStorage.removeItem('titan_session');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const cred = demoCredentials[email.toLowerCase()];
    if (!cred || cred.password !== password) {
      setIsLoading(false);
      return { success: false, error: 'Invalid email or password' };
    }
    
    const profile = initialProfiles[cred.profileIndex];
    const authUser: AuthUser = {
      id: profile.id,
      email: profile.email,
      role: profile.role,
    };
    
    setUser(authUser);
    localStorage.setItem('titan_session', JSON.stringify(authUser));
    setIsLoading(false);
    
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('titan_session');
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
