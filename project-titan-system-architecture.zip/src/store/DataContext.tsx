import React, { createContext, useContext, useState, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type {
  Profile,
  Vehicle,
  GarageJob,
  CarStandInventory,
  AuditTrail,
  VehicleIntakeForm,
  VehicleState,
  GarageStatus,
  UserRole,
} from '../types';
import {
  initialProfiles,
  initialVehicles,
  initialGarageJobs,
  initialCarStandInventory,
  initialAuditTrail,
} from './mockData';

interface DataContextType {
  // Data
  profiles: Profile[];
  vehicles: Vehicle[];
  garageJobs: GarageJob[];
  carStandInventory: CarStandInventory[];
  auditTrail: AuditTrail[];
  
  // Current user for audit
  currentUserId: string | null;
  setCurrentUserId: (id: string | null) => void;
  
  // Vehicle operations
  createVehicle: (form: VehicleIntakeForm) => Vehicle;
  updateVehicleStatus: (id: string, status: VehicleState) => void;
  getVehicleById: (id: string) => Vehicle | undefined;
  
  // Garage operations
  getGarageJobByVehicleId: (vehicleId: string) => GarageJob | undefined;
  updateGarageJob: (id: string, updates: Partial<GarageJob>) => void;
  closeGarageJob: (id: string, status: GarageStatus) => void;
  
  // Car Stand operations
  acceptToStand: (vehicleId: string, standFee: number, targetPrice: number) => void;
  executeSale: (inventoryId: string, salePrice: number) => void;
  getStandInventoryByVehicleId: (vehicleId: string) => CarStandInventory | undefined;
  
  // Profile operations
  updateProfileRole: (id: string, role: UserRole) => void;
  getProfileById: (id: string) => Profile | undefined;
  
  // Dashboard metrics
  getGarageRevenue: () => number;
  getStandRevenue: () => number;
  getDeferredAccounts: () => number;
  getAverageTurnaround: () => number;
}

const DataContext = createContext<DataContextType | null>(null);

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [profiles, setProfiles] = useState<Profile[]>(initialProfiles);
  const [vehicles, setVehicles] = useState<Vehicle[]>(initialVehicles);
  const [garageJobs, setGarageJobs] = useState<GarageJob[]>(initialGarageJobs);
  const [carStandInventory, setCarStandInventory] = useState<CarStandInventory[]>(initialCarStandInventory);
  const [auditTrail, setAuditTrail] = useState<AuditTrail[]>(initialAuditTrail);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  // Audit trail helper
  const addAuditEntry = useCallback((
    actionType: string,
    tableName: string,
    recordId: string,
    oldValue: Record<string, unknown> | null,
    newValue: Record<string, unknown> | null
  ) => {
    if (!currentUserId) return;
    
    const entry: AuditTrail = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      user_id: currentUserId,
      action_type: actionType,
      table_name: tableName,
      record_id: recordId,
      old_value: oldValue,
      new_value: newValue,
    };
    
    setAuditTrail(prev => [entry, ...prev]);
  }, [currentUserId]);

  // Vehicle operations
  const createVehicle = useCallback((form: VehicleIntakeForm): Vehicle => {
    const now = new Date().toISOString();
    const newVehicle: Vehicle = {
      id: uuidv4(),
      ...form,
      status: 'Under Maintenance',
      created_at: now,
      updated_at: now,
    };
    
    // Create associated garage job
    const newJob: GarageJob = {
      id: uuidv4(),
      vehicle_id: newVehicle.id,
      parts_cost: 0,
      labor_hours: 0,
      hourly_rate: 75.00,
      total_bill: 0,
      status: 'active',
      check_in_timestamp: now,
      closed_at: null,
    };
    
    setVehicles(prev => [...prev, newVehicle]);
    setGarageJobs(prev => [...prev, newJob]);
    
    addAuditEntry('INSERT', 'vehicles', newVehicle.id, null, { ...form, status: 'Under Maintenance' });
    addAuditEntry('INSERT', 'garage_jobs', newJob.id, null, { vehicle_id: newVehicle.id, status: 'active' });
    
    return newVehicle;
  }, [addAuditEntry]);

  const updateVehicleStatus = useCallback((id: string, status: VehicleState) => {
    setVehicles(prev => prev.map(v => {
      if (v.id === id) {
        addAuditEntry('UPDATE', 'vehicles', id, { status: v.status }, { status });
        return { ...v, status, updated_at: new Date().toISOString() };
      }
      return v;
    }));
  }, [addAuditEntry]);

  const getVehicleById = useCallback((id: string) => {
    return vehicles.find(v => v.id === id);
  }, [vehicles]);

  // Garage operations
  const getGarageJobByVehicleId = useCallback((vehicleId: string) => {
    return garageJobs.find(j => j.vehicle_id === vehicleId);
  }, [garageJobs]);

  const updateGarageJob = useCallback((id: string, updates: Partial<GarageJob>) => {
    setGarageJobs(prev => prev.map(j => {
      if (j.id === id) {
        const oldValues = { parts_cost: j.parts_cost, labor_hours: j.labor_hours };
        const newJob = { 
          ...j, 
          ...updates,
          total_bill: (updates.parts_cost ?? j.parts_cost) + 
                      ((updates.labor_hours ?? j.labor_hours) * (updates.hourly_rate ?? j.hourly_rate))
        };
        addAuditEntry('UPDATE', 'garage_jobs', id, oldValues, updates);
        return newJob;
      }
      return j;
    }));
  }, [addAuditEntry]);

  const closeGarageJob = useCallback((id: string, status: GarageStatus) => {
    const job = garageJobs.find(j => j.id === id);
    if (!job) return;
    
    const closedAt = new Date().toISOString();
    
    setGarageJobs(prev => prev.map(j => {
      if (j.id === id) {
        addAuditEntry('UPDATE', 'garage_jobs', id, { status: j.status }, { status, closed_at: closedAt });
        return { ...j, status, closed_at: closedAt };
      }
      return j;
    }));

    // Update vehicle status based on job closure type
    if (status === 'paid') {
      updateVehicleStatus(job.vehicle_id, 'Archived (Paid)');
    } else if (status === 'deferred') {
      updateVehicleStatus(job.vehicle_id, 'Pending Transfer');
    }
  }, [garageJobs, addAuditEntry, updateVehicleStatus]);

  // Car Stand operations
  const acceptToStand = useCallback((vehicleId: string, standFee: number, targetPrice: number) => {
    const now = new Date().toISOString();
    const newInventory: CarStandInventory = {
      id: uuidv4(),
      vehicle_id: vehicleId,
      fixed_stand_fee: standFee,
      target_list_price: targetPrice,
      final_sale_price: 0,
      final_payout: 0,
      status: 'active',
      entered_at: now,
      exited_at: null,
    };
    
    setCarStandInventory(prev => [...prev, newInventory]);
    updateVehicleStatus(vehicleId, 'Active on Stand');
    
    addAuditEntry('INSERT', 'car_stand_inventory', newInventory.id, null, {
      vehicle_id: vehicleId,
      fixed_stand_fee: standFee,
      target_list_price: targetPrice,
    });
  }, [addAuditEntry, updateVehicleStatus]);

  const executeSale = useCallback((inventoryId: string, salePrice: number) => {
    const inventory = carStandInventory.find(i => i.id === inventoryId);
    if (!inventory) return;
    
    const garageJob = garageJobs.find(j => j.vehicle_id === inventory.vehicle_id && j.status === 'deferred');
    const deferredRepairCost = garageJob?.total_bill ?? 0;
    
    // Financial bridge calculation
    const finalPayout = salePrice - inventory.fixed_stand_fee - deferredRepairCost;
    const exitedAt = new Date().toISOString();
    
    setCarStandInventory(prev => prev.map(i => {
      if (i.id === inventoryId) {
        addAuditEntry('UPDATE', 'car_stand_inventory', inventoryId, 
          { status: i.status }, 
          { status: 'settled', final_sale_price: salePrice, final_payout: finalPayout }
        );
        return {
          ...i,
          status: 'settled',
          final_sale_price: salePrice,
          final_payout: finalPayout,
          exited_at: exitedAt,
        };
      }
      return i;
    }));
    
    updateVehicleStatus(inventory.vehicle_id, 'Settled & Exited');
  }, [carStandInventory, garageJobs, addAuditEntry, updateVehicleStatus]);

  const getStandInventoryByVehicleId = useCallback((vehicleId: string) => {
    return carStandInventory.find(i => i.vehicle_id === vehicleId);
  }, [carStandInventory]);

  // Profile operations
  const updateProfileRole = useCallback((id: string, role: UserRole) => {
    setProfiles(prev => prev.map(p => {
      if (p.id === id) {
        addAuditEntry('UPDATE', 'profiles', id, { role: p.role }, { role });
        return { ...p, role, updated_at: new Date().toISOString() };
      }
      return p;
    }));
  }, [addAuditEntry]);

  const getProfileById = useCallback((id: string) => {
    return profiles.find(p => p.id === id);
  }, [profiles]);

  // Dashboard metrics
  const getGarageRevenue = useCallback(() => {
    return garageJobs
      .filter(j => j.status === 'paid')
      .reduce((sum, j) => sum + j.total_bill, 0);
  }, [garageJobs]);

  const getStandRevenue = useCallback(() => {
    return carStandInventory
      .filter(i => i.status === 'settled')
      .reduce((sum, i) => sum + i.fixed_stand_fee, 0);
  }, [carStandInventory]);

  const getDeferredAccounts = useCallback(() => {
    // Capital tied up in deferred jobs for vehicles on stand
    const activeStandVehicleIds = carStandInventory
      .filter(i => i.status === 'active')
      .map(i => i.vehicle_id);
    
    return garageJobs
      .filter(j => j.status === 'deferred' && activeStandVehicleIds.includes(j.vehicle_id))
      .reduce((sum, j) => sum + j.total_bill, 0);
  }, [garageJobs, carStandInventory]);

  const getAverageTurnaround = useCallback(() => {
    const settledWithTimes = carStandInventory
      .filter(i => i.status === 'settled' && i.exited_at)
      .map(i => {
        const vehicle = vehicles.find(v => v.id === i.vehicle_id);
        if (!vehicle) return null;
        const start = new Date(vehicle.created_at).getTime();
        const end = new Date(i.exited_at!).getTime();
        return (end - start) / (1000 * 60 * 60 * 24); // Days
      })
      .filter((d): d is number => d !== null);
    
    if (settledWithTimes.length === 0) return 0;
    return settledWithTimes.reduce((a, b) => a + b, 0) / settledWithTimes.length;
  }, [carStandInventory, vehicles]);

  return (
    <DataContext.Provider
      value={{
        profiles,
        vehicles,
        garageJobs,
        carStandInventory,
        auditTrail,
        currentUserId,
        setCurrentUserId,
        createVehicle,
        updateVehicleStatus,
        getVehicleById,
        getGarageJobByVehicleId,
        updateGarageJob,
        closeGarageJob,
        acceptToStand,
        executeSale,
        getStandInventoryByVehicleId,
        updateProfileRole,
        getProfileById,
        getGarageRevenue,
        getStandRevenue,
        getDeferredAccounts,
        getAverageTurnaround,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
