import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  Car, 
  User, 
  Wrench, 
  Clock, 
  ArrowLeft,
  CreditCard,
  ArrowRight,
  Calculator
} from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageHeader } from '../../components/layout/PageHeader';
import { formatDistanceToNow, format } from 'date-fns';

export function GarageJobCard() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { 
    getVehicleById, 
    getGarageJobByVehicleId, 
    updateGarageJob,
    closeGarageJob
  } = useData();
  
  const vehicle = id ? getVehicleById(id) : undefined;
  const garageJob = id ? getGarageJobByVehicleId(id) : undefined;
  
  const [partsCost, setPartsCost] = useState(garageJob?.parts_cost || 0);
  const [laborHours, setLaborHours] = useState(garageJob?.labor_hours || 0);
  const [hourlyRate, setHourlyRate] = useState(garageJob?.hourly_rate || 75);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Calculate totals
  const laborCost = laborHours * hourlyRate;
  const totalBill = partsCost + laborCost;
  
  // Update job when values change
  useEffect(() => {
    if (garageJob && garageJob.status === 'active') {
      const timeout = setTimeout(() => {
        updateGarageJob(garageJob.id, {
          parts_cost: partsCost,
          labor_hours: laborHours,
          hourly_rate: hourlyRate,
        });
      }, 500);
      return () => clearTimeout(timeout);
    }
  }, [partsCost, laborHours, hourlyRate, garageJob, updateGarageJob]);
  
  if (!vehicle || !garageJob) {
    return (
      <div className="text-center py-16">
        <Car className="w-16 h-16 mx-auto mb-4 text-gray-300" />
        <h2 className="text-xl font-semibold text-gray-700 mb-2">Vehicle Not Found</h2>
        <p className="text-gray-500 mb-4">The requested vehicle or job card could not be found.</p>
        <Link to="/operations/garage">
          <Button variant="secondary">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Workshop
          </Button>
        </Link>
      </div>
    );
  }
  
  const isEditable = garageJob.status === 'active';
  
  const handleCloseDirectRelease = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    closeGarageJob(garageJob.id, 'paid');
    setShowPaymentModal(false);
    navigate('/operations/garage');
  };
  
  const handleTransferToStand = async () => {
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    closeGarageJob(garageJob.id, 'deferred');
    setShowTransferModal(false);
    navigate('/operations/stand');
  };

  return (
    <div>
      <PageHeader 
        title="Job Card"
        subtitle={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
        action={
          <Link to="/operations/garage">
            <Button variant="ghost">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Workshop
            </Button>
          </Link>
        }
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Panel: Vehicle Details (Immutable) */}
        <div className="space-y-6">
          <Card>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Car className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Vehicle Details</h2>
                <p className="text-sm text-gray-500">Immutable record</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">VIN</p>
                  <code className="text-sm bg-gray-100 px-2 py-1 rounded block mt-1">
                    {vehicle.vin}
                  </code>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Engine Number</p>
                  <code className="text-sm bg-gray-100 px-2 py-1 rounded block mt-1">
                    {vehicle.engine_number}
                  </code>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Make</p>
                  <p className="font-medium">{vehicle.make}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Model</p>
                  <p className="font-medium">{vehicle.model}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Year</p>
                  <p className="font-medium">{vehicle.year}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Current Mileage</p>
                <p className="font-medium">{vehicle.current_mileage.toLocaleString()} miles</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Status</p>
                <Badge variant={vehicle.status === 'Under Maintenance' ? 'warning' : 'info'}>
                  {vehicle.status}
                </Badge>
              </div>
            </div>
          </Card>
          
          <Card>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <User className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Owner Details</h2>
                <p className="text-sm text-gray-500">Client information</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-500">Full Name</p>
                <p className="font-medium">{vehicle.owner_name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium">{vehicle.owner_phone}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium">{vehicle.owner_email}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">National ID</p>
                <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                  {vehicle.owner_national_id}
                </code>
              </div>
            </div>
          </Card>
        </div>
        
        {/* Right Panel: Job Card (Modifiable) */}
        <div className="space-y-6">
          <Card>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                  <Wrench className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">Job Card</h2>
                  <p className="text-sm text-gray-500">
                    <Clock className="w-4 h-4 inline mr-1" />
                    Checked in {formatDistanceToNow(new Date(garageJob.check_in_timestamp), { addSuffix: true })}
                  </p>
                </div>
              </div>
              <Badge variant={isEditable ? 'warning' : garageJob.status === 'paid' ? 'success' : 'info'}>
                {garageJob.status.charAt(0).toUpperCase() + garageJob.status.slice(1)}
              </Badge>
            </div>
            
            {/* Job Inputs */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Parts Cost ($)
                </label>
                <Input
                  type="number"
                  value={partsCost}
                  onChange={(e) => setPartsCost(parseFloat(e.target.value) || 0)}
                  disabled={!isEditable}
                  min={0}
                  step={0.01}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Labor Hours
                  </label>
                  <Input
                    type="number"
                    value={laborHours}
                    onChange={(e) => setLaborHours(parseFloat(e.target.value) || 0)}
                    disabled={!isEditable}
                    min={0}
                    step={0.5}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Hourly Rate ($)
                  </label>
                  <Input
                    type="number"
                    value={hourlyRate}
                    onChange={(e) => setHourlyRate(parseFloat(e.target.value) || 0)}
                    disabled={!isEditable}
                    min={0}
                    step={1}
                  />
                </div>
              </div>
            </div>
          </Card>
          
          {/* Dynamic Billing Widget */}
          <Card className="bg-gradient-to-br from-slate-800 to-slate-900 text-white">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                <Calculator className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-semibold">Billing Summary</h2>
                <p className="text-sm text-slate-400">Real-time calculation</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-300">Parts Cost</span>
                <span className="font-medium">${partsCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Labor ({laborHours}h × ${hourlyRate}/h)</span>
                <span className="font-medium">${laborCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <div className="border-t border-slate-600 pt-3 mt-3">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">Total Bill</span>
                  <span className="text-2xl font-bold text-green-400">
                    ${totalBill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-white/5 rounded-lg">
              <p className="text-xs text-slate-400">
                <strong>Formula:</strong> Total = Parts Cost + (Labor Hours × Hourly Rate)
              </p>
            </div>
          </Card>
          
          {/* Action Footer */}
          {isEditable && (
            <Card>
              <h3 className="font-semibold text-gray-900 mb-4">Actions</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Button
                  variant="success"
                  className="w-full gap-2"
                  onClick={() => setShowPaymentModal(true)}
                >
                  <CreditCard className="w-4 h-4" />
                  Close Job - Direct Release
                </Button>
                <Button
                  variant="primary"
                  className="w-full gap-2"
                  onClick={() => setShowTransferModal(true)}
                >
                  <ArrowRight className="w-4 h-4" />
                  Transfer to Stand - Consign
                </Button>
              </div>
            </Card>
          )}
          
          {!isEditable && garageJob.closed_at && (
            <Card className="bg-gray-50">
              <p className="text-sm text-gray-600 text-center">
                This job was closed on {format(new Date(garageJob.closed_at), 'PPP')}
              </p>
            </Card>
          )}
        </div>
      </div>
      
      {/* Payment Modal */}
      <Modal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        title="Confirm Direct Release"
        size="md"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Customer will pay the full amount and the vehicle will be released.
          </p>
          
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="text-green-700">Amount Due</span>
              <span className="text-2xl font-bold text-green-700">
                ${totalBill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
          
          <div className="flex gap-3 mt-6">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => setShowPaymentModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="success"
              className="flex-1"
              onClick={handleCloseDirectRelease}
              isLoading={isProcessing}
            >
              Confirm Payment
            </Button>
          </div>
        </div>
      </Modal>
      
      {/* Transfer Modal */}
      <Modal
        isOpen={showTransferModal}
        onClose={() => setShowTransferModal(false)}
        title="Transfer to Car Stand"
        size="md"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            The repair bill will be deferred and deducted from the final sale price when the vehicle is sold.
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex justify-between items-center">
              <span className="text-blue-700">Deferred Amount</span>
              <span className="text-2xl font-bold text-blue-700">
                ${totalBill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>
            <p className="text-sm text-blue-600 mt-2">
              This amount will be automatically deducted when the vehicle is sold.
            </p>
          </div>
          
          <div className="flex gap-3 mt-6">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => setShowTransferModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              className="flex-1"
              onClick={handleTransferToStand}
              isLoading={isProcessing}
            >
              Confirm Transfer
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
