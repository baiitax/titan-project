import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Car, Wrench, Store, Search, ChevronRight } from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { PageHeader } from '../../components/layout/PageHeader';
import type { VehicleState } from '../../types';

const statusBadgeVariant: Record<VehicleState, 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple'> = {
  'Under Maintenance': 'warning',
  'Pending Transfer': 'info',
  'Active on Stand': 'purple',
  'Settled & Exited': 'success',
  'Archived (Paid)': 'success',
  'Archived (Closed)': 'default',
};

export function OperationsDashboard() {
  const { vehicles, garageJobs } = useData();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<VehicleState | 'all'>('all');
  
  // Filter vehicles
  const filteredVehicles = useMemo(() => {
    return vehicles.filter(vehicle => {
      // Status filter
      if (statusFilter !== 'all' && vehicle.status !== statusFilter) return false;
      
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          vehicle.vin.toLowerCase().includes(query) ||
          vehicle.owner_name.toLowerCase().includes(query) ||
          vehicle.make.toLowerCase().includes(query) ||
          vehicle.model.toLowerCase().includes(query)
        );
      }
      
      return true;
    });
  }, [vehicles, searchQuery, statusFilter]);
  
  // Active vehicles only (not archived)
  const activeVehicles = filteredVehicles.filter(v => 
    !v.status.includes('Archived') && v.status !== 'Settled & Exited'
  );
  
  // Stats
  const stats = {
    underMaintenance: vehicles.filter(v => v.status === 'Under Maintenance').length,
    pendingTransfer: vehicles.filter(v => v.status === 'Pending Transfer').length,
    activeOnStand: vehicles.filter(v => v.status === 'Active on Stand').length,
    activeJobs: garageJobs.filter(j => j.status === 'active').length,
  };

  return (
    <div>
      <PageHeader 
        title="Operations Dashboard"
        subtitle="Manage vehicles, garage jobs, and car stand inventory"
      />
      
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Link to="/operations/intake">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-blue-500">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                  <Car className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">New Vehicle Intake</h3>
                  <p className="text-sm text-gray-500">Register a new vehicle</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </Card>
        </Link>
        
        <Link to="/operations/garage">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-orange-500">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-orange-100 flex items-center justify-center">
                  <Wrench className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Active Garage</h3>
                  <p className="text-sm text-gray-500">{stats.activeJobs} active jobs</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </Card>
        </Link>
        
        <Link to="/operations/stand">
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-purple-500">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Store className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">Car Stand</h3>
                  <p className="text-sm text-gray-500">{stats.activeOnStand} on stand</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
          </Card>
        </Link>
      </div>
      
      {/* Status Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card padding="sm" className="text-center">
          <p className="text-2xl font-bold text-yellow-600">{stats.underMaintenance}</p>
          <p className="text-sm text-gray-500">Under Maintenance</p>
        </Card>
        <Card padding="sm" className="text-center">
          <p className="text-2xl font-bold text-blue-600">{stats.pendingTransfer}</p>
          <p className="text-sm text-gray-500">Pending Transfer</p>
        </Card>
        <Card padding="sm" className="text-center">
          <p className="text-2xl font-bold text-purple-600">{stats.activeOnStand}</p>
          <p className="text-sm text-gray-500">Active on Stand</p>
        </Card>
        <Card padding="sm" className="text-center">
          <p className="text-2xl font-bold text-green-600">{vehicles.filter(v => v.status.includes('Settled') || v.status.includes('Archived')).length}</p>
          <p className="text-sm text-gray-500">Completed</p>
        </Card>
      </div>
      
      {/* Vehicle Table */}
      <Card>
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by VIN, owner name, make or model..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as VehicleState | 'all')}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Statuses</option>
            <option value="Under Maintenance">Under Maintenance</option>
            <option value="Pending Transfer">Pending Transfer</option>
            <option value="Active on Stand">Active on Stand</option>
            <option value="Settled & Exited">Settled & Exited</option>
            <option value="Archived (Paid)">Archived (Paid)</option>
          </select>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Vehicle</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">VIN</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Owner</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Status</th>
                <th className="text-right py-3 px-4 text-sm font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {activeVehicles.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-500">
                    No vehicles found matching your criteria
                  </td>
                </tr>
              ) : (
                activeVehicles.map((vehicle) => (
                  <tr key={vehicle.id} className="hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">
                        {vehicle.year} {vehicle.make} {vehicle.model}
                      </div>
                      <div className="text-sm text-gray-500">
                        {vehicle.current_mileage.toLocaleString()} miles
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                        {vehicle.vin}
                      </code>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-gray-900">{vehicle.owner_name}</div>
                      <div className="text-sm text-gray-500">{vehicle.owner_phone}</div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={statusBadgeVariant[vehicle.status]}>
                        {vehicle.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {vehicle.status === 'Under Maintenance' && (
                        <Link to={`/operations/garage/${vehicle.id}`}>
                          <Button size="sm" variant="ghost">View Job</Button>
                        </Link>
                      )}
                      {vehicle.status === 'Pending Transfer' && (
                        <Link to="/operations/stand">
                          <Button size="sm" variant="ghost">Accept to Stand</Button>
                        </Link>
                      )}
                      {vehicle.status === 'Active on Stand' && (
                        <Link to="/operations/stand">
                          <Button size="sm" variant="ghost">View on Stand</Button>
                        </Link>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
