import { useState, useMemo } from 'react';
import { Store, ArrowRight, DollarSign, Check, Clock, FileText } from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { PageHeader } from '../../components/layout/PageHeader';
import { formatDistanceToNow, format } from 'date-fns';
import { jsPDF } from 'jspdf';
import type { Vehicle, CarStandInventory, GarageJob } from '../../types';

export function CarStand() {
  const { 
    vehicles, 
    garageJobs,
    carStandInventory, 
    acceptToStand, 
    executeSale,
    getGarageJobByVehicleId 
  } = useData();
  
  const [selectedVehicleForAccept, setSelectedVehicleForAccept] = useState<Vehicle | null>(null);
  const [selectedInventoryForSale, setSelectedInventoryForSale] = useState<(CarStandInventory & { vehicle: Vehicle; garageJob?: GarageJob }) | null>(null);
  
  // Accept to Stand form
  const [standFee, setStandFee] = useState(500);
  const [targetPrice, setTargetPrice] = useState(15000);
  
  // Sale form
  const [salePrice, setSalePrice] = useState(0);
  
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Pending transfers (vehicles ready to be accepted to stand)
  const pendingTransfers = useMemo(() => {
    return vehicles.filter(v => v.status === 'Pending Transfer');
  }, [vehicles]);
  
  // Active on stand
  const activeOnStand = useMemo(() => {
    return carStandInventory
      .filter(i => i.status === 'active')
      .map(inventory => {
        const vehicle = vehicles.find(v => v.id === inventory.vehicle_id);
        const garageJob = garageJobs.find(j => j.vehicle_id === inventory.vehicle_id && j.status === 'deferred');
        return { ...inventory, vehicle: vehicle!, garageJob };
      })
      .filter(i => i.vehicle);
  }, [carStandInventory, vehicles, garageJobs]);
  
  // Settled
  const settledInventory = useMemo(() => {
    return carStandInventory
      .filter(i => i.status === 'settled')
      .map(inventory => {
        const vehicle = vehicles.find(v => v.id === inventory.vehicle_id);
        const garageJob = garageJobs.find(j => j.vehicle_id === inventory.vehicle_id);
        return { ...inventory, vehicle: vehicle!, garageJob };
      })
      .filter(i => i.vehicle)
      .slice(0, 5);
  }, [carStandInventory, vehicles, garageJobs]);
  
  const handleAcceptToStand = async () => {
    if (!selectedVehicleForAccept) return;
    
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    acceptToStand(selectedVehicleForAccept.id, standFee, targetPrice);
    
    setSelectedVehicleForAccept(null);
    setStandFee(500);
    setTargetPrice(15000);
    setIsProcessing(false);
  };
  
  const handleExecuteSale = async () => {
    if (!selectedInventoryForSale || salePrice <= 0) return;
    
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    executeSale(selectedInventoryForSale.id, salePrice);
    
    // Generate PDF after sale
    generateSettlementPDF(selectedInventoryForSale, salePrice);
    
    setSelectedInventoryForSale(null);
    setSalePrice(0);
    setIsProcessing(false);
  };
  
  const generateSettlementPDF = (
    inventory: CarStandInventory & { vehicle: Vehicle; garageJob?: GarageJob },
    finalSalePrice: number
  ) => {
    const doc = new jsPDF();
    const vehicle = inventory.vehicle;
    const deferredRepairs = inventory.garageJob?.total_bill || 0;
    const standFee = inventory.fixed_stand_fee;
    const finalPayout = finalSalePrice - standFee - deferredRepairs;
    
    // Header
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.text('PROJECT TITAN', 105, 25, { align: 'center' });
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('Sale Settlement Statement', 105, 33, { align: 'center' });
    
    // Line
    doc.setLineWidth(0.5);
    doc.line(20, 40, 190, 40);
    
    // Customer Info
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Customer Information', 20, 55);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Name: ${vehicle.owner_name}`, 20, 65);
    doc.text(`Phone: ${vehicle.owner_phone}`, 20, 72);
    doc.text(`Email: ${vehicle.owner_email}`, 20, 79);
    doc.text(`National ID: ${vehicle.owner_national_id}`, 20, 86);
    
    // Vehicle Info
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Vehicle Information', 20, 102);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`VIN: ${vehicle.vin}`, 20, 112);
    doc.text(`Make: ${vehicle.make}`, 20, 119);
    doc.text(`Model: ${vehicle.model}`, 20, 126);
    doc.text(`Year: ${vehicle.year}`, 20, 133);
    doc.text(`Mileage: ${vehicle.current_mileage.toLocaleString()} miles`, 20, 140);
    
    // Billing Summary
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Settlement Summary', 20, 160);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    
    const startY = 170;
    const colX = 150;
    
    doc.text('Gross Sale Price:', 20, startY);
    doc.text(`$${finalSalePrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, colX, startY, { align: 'right' });
    
    doc.text('Less: Stand Fee:', 20, startY + 10);
    doc.text(`-$${standFee.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, colX, startY + 10, { align: 'right' });
    
    doc.text('Less: Deferred Repairs:', 20, startY + 20);
    doc.text(`-$${deferredRepairs.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, colX, startY + 20, { align: 'right' });
    
    doc.setLineWidth(0.3);
    doc.line(20, startY + 27, 150, startY + 27);
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text('Final Owner Remittance:', 20, startY + 37);
    doc.text(`$${finalPayout.toLocaleString(undefined, { minimumFractionDigits: 2 })}`, colX, startY + 37, { align: 'right' });
    
    // Footer
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated on ${format(new Date(), 'PPpp')}`, 105, 280, { align: 'center' });
    doc.text('This is an official settlement document from Project Titan.', 105, 286, { align: 'center' });
    
    // Save the PDF
    doc.save(`settlement_${vehicle.vin}_${format(new Date(), 'yyyyMMdd')}.pdf`);
  };
  
  // Calculate potential payout for preview
  const calculatePotentialPayout = () => {
    if (!selectedInventoryForSale) return 0;
    const deferredRepairs = selectedInventoryForSale.garageJob?.total_bill || 0;
    return salePrice - selectedInventoryForSale.fixed_stand_fee - deferredRepairs;
  };

  return (
    <div>
      <PageHeader 
        title="Car Stand"
        subtitle="Manage consignment inventory and sales"
      />
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card padding="sm" className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
            <Clock className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">{pendingTransfers.length}</p>
            <p className="text-sm text-gray-500">Pending Transfers</p>
          </div>
        </Card>
        
        <Card padding="sm" className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
            <Store className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">{activeOnStand.length}</p>
            <p className="text-sm text-gray-500">Active on Stand</p>
          </div>
        </Card>
        
        <Card padding="sm" className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
            <DollarSign className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">
              ${carStandInventory
                .filter(i => i.status === 'settled')
                .reduce((sum, i) => sum + i.fixed_stand_fee, 0)
                .toLocaleString()}
            </p>
            <p className="text-sm text-gray-500">Total Stand Revenue</p>
          </div>
        </Card>
      </div>
      
      {/* Pending Transfers */}
      <Card className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-blue-500"></span>
          Pending Transfers
        </h2>
        
        {pendingTransfers.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Clock className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>No vehicles pending transfer</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingTransfers.map((vehicle) => {
              const garageJob = getGarageJobByVehicleId(vehicle.id);
              return (
                <div
                  key={vehicle.id}
                  className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200"
                >
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {vehicle.year} {vehicle.make} {vehicle.model}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {vehicle.owner_name} • VIN: {vehicle.vin.slice(-6)}
                    </p>
                    {garageJob && (
                      <p className="text-sm text-blue-600 mt-1">
                        Deferred repairs: ${garageJob.total_bill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </p>
                    )}
                  </div>
                  <Button
                    size="sm"
                    onClick={() => setSelectedVehicleForAccept(vehicle)}
                  >
                    Accept to Lot
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </Card>
      
      {/* Active on Stand */}
      <Card className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-purple-500"></span>
          Active on Stand
        </h2>
        
        {activeOnStand.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Store className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>No vehicles currently on the stand</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeOnStand.map((item) => (
              <div
                key={item.id}
                className="p-4 bg-purple-50 rounded-lg border border-purple-200"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {item.vehicle.year} {item.vehicle.make} {item.vehicle.model}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {item.vehicle.owner_name}
                    </p>
                  </div>
                  <Badge variant="purple">On Stand</Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                  <div className="bg-white rounded p-2">
                    <p className="text-gray-500">Target Price</p>
                    <p className="font-semibold">${item.target_list_price.toLocaleString()}</p>
                  </div>
                  <div className="bg-white rounded p-2">
                    <p className="text-gray-500">Stand Fee</p>
                    <p className="font-semibold">${item.fixed_stand_fee.toLocaleString()}</p>
                  </div>
                </div>
                
                {item.garageJob && (
                  <p className="text-xs text-purple-600 mb-3">
                    Deferred repairs: ${item.garageJob.total_bill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                )}
                
                <p className="text-xs text-gray-500 mb-3">
                  Listed {formatDistanceToNow(new Date(item.entered_at), { addSuffix: true })}
                </p>
                
                <Button
                  variant="success"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setSelectedInventoryForSale(item);
                    setSalePrice(item.target_list_price);
                  }}
                >
                  <DollarSign className="w-4 h-4 mr-1" />
                  Execute Sale
                </Button>
              </div>
            ))}
          </div>
        )}
      </Card>
      
      {/* Recently Settled */}
      {settledInventory.length > 0 && (
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            Recently Settled
          </h2>
          
          <div className="space-y-3">
            {settledInventory.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-4 bg-green-50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center">
                    <Check className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {item.vehicle.year} {item.vehicle.make} {item.vehicle.model}
                    </h3>
                    <p className="text-sm text-gray-500">
                      Sold for ${item.final_sale_price.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-green-700">
                    Payout: ${item.final_payout.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs text-gray-500">
                    {item.exited_at && format(new Date(item.exited_at), 'PP')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
      
      {/* Accept to Stand Modal */}
      <Modal
        isOpen={!!selectedVehicleForAccept}
        onClose={() => setSelectedVehicleForAccept(null)}
        title="Accept Vehicle to Stand"
        size="md"
      >
        {selectedVehicleForAccept && (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900">
                {selectedVehicleForAccept.year} {selectedVehicleForAccept.make} {selectedVehicleForAccept.model}
              </h3>
              <p className="text-sm text-gray-500">
                Owner: {selectedVehicleForAccept.owner_name}
              </p>
            </div>
            
            <Input
              label="Fixed Stand Fee ($)"
              type="number"
              value={standFee}
              onChange={(e) => setStandFee(parseFloat(e.target.value) || 0)}
              min={0}
              step={50}
            />
            
            <Input
              label="Target List Price ($)"
              type="number"
              value={targetPrice}
              onChange={(e) => setTargetPrice(parseFloat(e.target.value) || 0)}
              min={0}
              step={500}
            />
            
            <div className="flex gap-3 mt-6">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => setSelectedVehicleForAccept(null)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                className="flex-1"
                onClick={handleAcceptToStand}
                isLoading={isProcessing}
              >
                Accept to Stand
              </Button>
            </div>
          </div>
        )}
      </Modal>
      
      {/* Execute Sale Modal */}
      <Modal
        isOpen={!!selectedInventoryForSale}
        onClose={() => setSelectedInventoryForSale(null)}
        title="Execute Sale"
        size="lg"
      >
        {selectedInventoryForSale && (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900">
                {selectedInventoryForSale.vehicle.year} {selectedInventoryForSale.vehicle.make} {selectedInventoryForSale.vehicle.model}
              </h3>
              <p className="text-sm text-gray-500">
                Owner: {selectedInventoryForSale.vehicle.owner_name}
              </p>
            </div>
            
            <Input
              label="Final Sale Price ($)"
              type="number"
              value={salePrice}
              onChange={(e) => setSalePrice(parseFloat(e.target.value) || 0)}
              min={0}
              step={100}
            />
            
            {/* Settlement Preview */}
            <div className="bg-slate-800 text-white rounded-lg p-4 space-y-2">
              <h4 className="font-semibold mb-3">Settlement Preview</h4>
              
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Gross Sale Price</span>
                <span>${salePrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Less: Stand Fee</span>
                <span className="text-red-400">
                  -${selectedInventoryForSale.fixed_stand_fee.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Less: Deferred Repairs</span>
                <span className="text-red-400">
                  -${(selectedInventoryForSale.garageJob?.total_bill || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
              
              <div className="border-t border-slate-600 pt-2 mt-2">
                <div className="flex justify-between">
                  <span className="font-semibold">Final Owner Remittance</span>
                  <span className={`font-bold text-lg ${calculatePotentialPayout() >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    ${calculatePotentialPayout().toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2">
              <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-blue-700">
                A settlement PDF document will be automatically generated and downloaded upon confirmation.
              </p>
            </div>
            
            <div className="flex gap-3 mt-6">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => setSelectedInventoryForSale(null)}
              >
                Cancel
              </Button>
              <Button
                variant="success"
                className="flex-1"
                onClick={handleExecuteSale}
                isLoading={isProcessing}
                disabled={salePrice <= 0}
              >
                Confirm Sale & Generate PDF
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
