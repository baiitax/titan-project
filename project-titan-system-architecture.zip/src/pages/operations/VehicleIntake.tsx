import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Car, User, ArrowRight, Check } from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { PageHeader } from '../../components/layout/PageHeader';
import type { VehicleIntakeForm } from '../../types';

const initialForm: VehicleIntakeForm = {
  vin: '',
  make: '',
  model: '',
  year: new Date().getFullYear(),
  engine_number: '',
  current_mileage: 0,
  owner_name: '',
  owner_phone: '',
  owner_email: '',
  owner_national_id: '',
};

export function VehicleIntake() {
  const navigate = useNavigate();
  const { createVehicle } = useData();
  const [form, setForm] = useState<VehicleIntakeForm>(initialForm);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof VehicleIntakeForm, string>>>({});
  
  const updateForm = (field: keyof VehicleIntakeForm, value: string | number) => {
    setForm(prev => ({ ...prev, [field]: value }));
    // Clear error when field is modified
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof VehicleIntakeForm, string>> = {};
    
    if (!form.vin || form.vin.length < 10) {
      newErrors.vin = 'VIN must be at least 10 characters';
    }
    if (!form.make) newErrors.make = 'Make is required';
    if (!form.model) newErrors.model = 'Model is required';
    if (!form.year || form.year < 1900 || form.year > new Date().getFullYear() + 1) {
      newErrors.year = 'Enter a valid year';
    }
    if (!form.engine_number) newErrors.engine_number = 'Engine number is required';
    if (!form.current_mileage && form.current_mileage !== 0) {
      newErrors.current_mileage = 'Mileage is required';
    }
    if (!form.owner_name) newErrors.owner_name = 'Owner name is required';
    if (!form.owner_phone) newErrors.owner_phone = 'Phone number is required';
    if (!form.owner_email || !form.owner_email.includes('@')) {
      newErrors.owner_email = 'Valid email is required';
    }
    if (!form.owner_national_id) newErrors.owner_national_id = 'National ID is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const vehicle = createVehicle(form);
    
    // Navigate to the garage job for this vehicle
    navigate(`/operations/garage/${vehicle.id}`);
  };

  return (
    <div>
      <PageHeader 
        title="Vehicle Intake"
        subtitle="Register a new vehicle for maintenance"
      />
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Section A: Vehicle Parameters */}
          <Card>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Car className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Vehicle Information</h2>
                <p className="text-sm text-gray-500">Enter vehicle details</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <Input
                label="VIN (Vehicle Identification Number)"
                value={form.vin}
                onChange={(e) => updateForm('vin', e.target.value.toUpperCase())}
                placeholder="e.g., 1HGBH41JXMN109186"
                error={errors.vin}
                maxLength={17}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Make"
                  value={form.make}
                  onChange={(e) => updateForm('make', e.target.value)}
                  placeholder="e.g., Toyota"
                  error={errors.make}
                />
                <Input
                  label="Model"
                  value={form.model}
                  onChange={(e) => updateForm('model', e.target.value)}
                  placeholder="e.g., Camry"
                  error={errors.model}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Year"
                  type="number"
                  value={form.year || ''}
                  onChange={(e) => updateForm('year', parseInt(e.target.value) || 0)}
                  placeholder="e.g., 2021"
                  error={errors.year}
                  min={1900}
                  max={new Date().getFullYear() + 1}
                />
                <Input
                  label="Current Mileage"
                  type="number"
                  value={form.current_mileage || ''}
                  onChange={(e) => updateForm('current_mileage', parseInt(e.target.value) || 0)}
                  placeholder="e.g., 45000"
                  error={errors.current_mileage}
                  min={0}
                />
              </div>
              
              <Input
                label="Engine Number"
                value={form.engine_number}
                onChange={(e) => updateForm('engine_number', e.target.value.toUpperCase())}
                placeholder="e.g., EN123456789"
                error={errors.engine_number}
              />
            </div>
          </Card>
          
          {/* Section B: Client Parameters */}
          <Card>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <User className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Owner Information</h2>
                <p className="text-sm text-gray-500">Enter client details</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <Input
                label="Full Name"
                value={form.owner_name}
                onChange={(e) => updateForm('owner_name', e.target.value)}
                placeholder="e.g., John Smith"
                error={errors.owner_name}
              />
              
              <Input
                label="Phone Number"
                type="tel"
                value={form.owner_phone}
                onChange={(e) => updateForm('owner_phone', e.target.value)}
                placeholder="e.g., +1-555-0101"
                error={errors.owner_phone}
              />
              
              <Input
                label="Email Address"
                type="email"
                value={form.owner_email}
                onChange={(e) => updateForm('owner_email', e.target.value)}
                placeholder="e.g., john.smith@email.com"
                error={errors.owner_email}
              />
              
              <Input
                label="National ID"
                value={form.owner_national_id}
                onChange={(e) => updateForm('owner_national_id', e.target.value.toUpperCase())}
                placeholder="e.g., ID-12345678"
                error={errors.owner_national_id}
              />
            </div>
          </Card>
        </div>
        
        {/* Submit Button */}
        <div className="mt-6 flex justify-end gap-4">
          <Button
            type="button"
            variant="secondary"
            onClick={() => navigate('/operations/dashboard')}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            isLoading={isSubmitting}
            className="gap-2"
          >
            <Check className="w-4 h-4" />
            Register Vehicle & Create Job Card
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}
