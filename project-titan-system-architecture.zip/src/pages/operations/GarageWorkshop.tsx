import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Wrench, Clock, DollarSign, ChevronRight } from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { PageHeader } from '../../components/layout/PageHeader';
import { formatDistanceToNow } from 'date-fns';

export function GarageWorkshop() {
  const { vehicles, garageJobs } = useData();
  
  const activeJobs = useMemo(() => {
    return garageJobs
      .filter(job => job.status === 'active')
      .map(job => {
        const vehicle = vehicles.find(v => v.id === job.vehicle_id);
        return { ...job, vehicle };
      })
      .filter(job => job.vehicle)
      .sort((a, b) => new Date(b.check_in_timestamp).getTime() - new Date(a.check_in_timestamp).getTime());
  }, [garageJobs, vehicles]);
  
  const deferredJobs = useMemo(() => {
    return garageJobs
      .filter(job => job.status === 'deferred')
      .map(job => {
        const vehicle = vehicles.find(v => v.id === job.vehicle_id);
        return { ...job, vehicle };
      })
      .filter(job => job.vehicle);
  }, [garageJobs, vehicles]);
  
  const paidJobs = useMemo(() => {
    return garageJobs
      .filter(job => job.status === 'paid')
      .map(job => {
        const vehicle = vehicles.find(v => v.id === job.vehicle_id);
        return { ...job, vehicle };
      })
      .filter(job => job.vehicle)
      .slice(0, 5);
  }, [garageJobs, vehicles]);

  return (
    <div>
      <PageHeader 
        title="Garage Workshop"
        subtitle="Manage active maintenance jobs and job cards"
      />
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card padding="sm" className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-orange-100 flex items-center justify-center">
            <Wrench className="w-6 h-6 text-orange-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">{activeJobs.length}</p>
            <p className="text-sm text-gray-500">Active Jobs</p>
          </div>
        </Card>
        
        <Card padding="sm" className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
            <Clock className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">{deferredJobs.length}</p>
            <p className="text-sm text-gray-500">Deferred to Stand</p>
          </div>
        </Card>
        
        <Card padding="sm" className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
            <DollarSign className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">
              ${garageJobs.filter(j => j.status === 'paid').reduce((sum, j) => sum + j.total_bill, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </p>
            <p className="text-sm text-gray-500">Total Paid Revenue</p>
          </div>
        </Card>
      </div>
      
      {/* Active Jobs */}
      <Card className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-orange-500"></span>
          Active Jobs
        </h2>
        
        {activeJobs.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Wrench className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>No active jobs in the workshop</p>
            <Link to="/operations/intake" className="text-blue-600 hover:underline text-sm mt-1 inline-block">
              Create a new vehicle intake
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {activeJobs.map((job) => (
              <Link
                key={job.id}
                to={`/operations/garage/${job.vehicle_id}`}
                className="block"
              >
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-white border border-gray-200 flex items-center justify-center">
                      <Wrench className="w-6 h-6 text-orange-500" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">
                        {job.vehicle?.year} {job.vehicle?.make} {job.vehicle?.model}
                      </h3>
                      <p className="text-sm text-gray-500">
                        VIN: {job.vehicle?.vin} • {job.vehicle?.owner_name}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">
                        ${job.total_bill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(job.check_in_timestamp), { addSuffix: true })}
                      </p>
                    </div>
                    <Badge variant="warning">Active</Badge>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </Card>
      
      {/* Deferred Jobs */}
      {deferredJobs.length > 0 && (
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            Deferred to Stand
          </h2>
          
          <div className="space-y-3">
            {deferredJobs.map((job) => (
              <div
                key={job.id}
                className="flex items-center justify-between p-4 bg-blue-50 rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-white border border-blue-200 flex items-center justify-center">
                    <Clock className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {job.vehicle?.year} {job.vehicle?.make} {job.vehicle?.model}
                    </h3>
                    <p className="text-sm text-gray-500">
                      VIN: {job.vehicle?.vin}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="font-semibold text-blue-700">
                      ${job.total_bill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-gray-500">Deferred bill</p>
                  </div>
                  <Badge variant="info">Deferred</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
      
      {/* Recent Paid Jobs */}
      {paidJobs.length > 0 && (
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
            Recently Paid Jobs
          </h2>
          
          <div className="space-y-3">
            {paidJobs.map((job) => (
              <div
                key={job.id}
                className="flex items-center justify-between p-4 bg-green-50 rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-white border border-green-200 flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-500" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {job.vehicle?.year} {job.vehicle?.make} {job.vehicle?.model}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {job.vehicle?.owner_name}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="font-semibold text-green-700">
                      ${job.total_bill.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-gray-500">Paid in full</p>
                  </div>
                  <Badge variant="success">Paid</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
