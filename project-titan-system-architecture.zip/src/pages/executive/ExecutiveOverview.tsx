import { useMemo } from 'react';
import { 
  Wrench, 
  Store, 
  AlertTriangle, 
  Clock,
  TrendingUp,
  TrendingDown,
  Activity
} from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { PageHeader } from '../../components/layout/PageHeader';
import { format, subDays } from 'date-fns';

export function ExecutiveOverview() {
  const { 
    vehicles,
    garageJobs, 
    carStandInventory,
    getGarageRevenue, 
    getStandRevenue, 
    getDeferredAccounts,
    getAverageTurnaround 
  } = useData();
  
  const garageRevenue = getGarageRevenue();
  const standRevenue = getStandRevenue();
  const deferredRisk = getDeferredAccounts();
  const avgTurnaround = getAverageTurnaround();
  
  // Calculate recent activity
  const recentActivity = useMemo(() => {
    const thirtyDaysAgo = subDays(new Date(), 30);
    
    const recentSales = carStandInventory.filter(
      i => i.status === 'settled' && i.exited_at && new Date(i.exited_at) >= thirtyDaysAgo
    );
    
    const recentGarageJobs = garageJobs.filter(
      j => j.status === 'paid' && j.closed_at && new Date(j.closed_at) >= thirtyDaysAgo
    );
    
    return {
      salesCount: recentSales.length,
      salesRevenue: recentSales.reduce((sum, s) => sum + s.fixed_stand_fee, 0),
      garageCount: recentGarageJobs.length,
      garageRevenue: recentGarageJobs.reduce((sum, j) => sum + j.total_bill, 0),
    };
  }, [carStandInventory, garageJobs]);
  
  // Pipeline metrics
  const pipeline = useMemo(() => ({
    underMaintenance: vehicles.filter(v => v.status === 'Under Maintenance').length,
    pendingTransfer: vehicles.filter(v => v.status === 'Pending Transfer').length,
    activeOnStand: vehicles.filter(v => v.status === 'Active on Stand').length,
    totalActive: vehicles.filter(v => !v.status.includes('Archived') && v.status !== 'Settled & Exited').length,
  }), [vehicles]);

  return (
    <div>
      <PageHeader 
        title="Executive Overview"
        subtitle={`Financial dashboard as of ${format(new Date(), 'PPPP')}`}
      />
      
      {/* Main KPI Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Widget 1: Garage Ledger */}
        <Card className="border-l-4 border-l-orange-500">
          <div className="flex items-start justify-between">
            <div className="w-12 h-12 rounded-lg bg-orange-100 flex items-center justify-center">
              <Wrench className="w-6 h-6 text-orange-600" />
            </div>
            <Badge variant="success" size="md">
              <TrendingUp className="w-3 h-3 mr-1" />
              Revenue
            </Badge>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">Garage Ledger</p>
            <p className="text-3xl font-bold text-gray-900">
              ${garageRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Total from paid jobs
            </p>
          </div>
        </Card>
        
        {/* Widget 2: Car Stand Ledger */}
        <Card className="border-l-4 border-l-purple-500">
          <div className="flex items-start justify-between">
            <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
              <Store className="w-6 h-6 text-purple-600" />
            </div>
            <Badge variant="success" size="md">
              <TrendingUp className="w-3 h-3 mr-1" />
              Revenue
            </Badge>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">Car Stand Ledger</p>
            <p className="text-3xl font-bold text-gray-900">
              ${standRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Total from stand fees
            </p>
          </div>
        </Card>
        
        {/* Widget 3: Deferred Accounts Receivable */}
        <Card className="border-l-4 border-l-red-500">
          <div className="flex items-start justify-between">
            <div className="w-12 h-12 rounded-lg bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <Badge variant={deferredRisk > 5000 ? 'danger' : 'warning'} size="md">
              {deferredRisk > 5000 ? (
                <>
                  <TrendingDown className="w-3 h-3 mr-1" />
                  High Risk
                </>
              ) : (
                'At Risk'
              )}
            </Badge>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">Deferred A/R Risk</p>
            <p className="text-3xl font-bold text-gray-900">
              ${deferredRisk.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Capital tied in unsold inventory
            </p>
          </div>
        </Card>
        
        {/* Widget 4: Throughput Efficiency */}
        <Card className="border-l-4 border-l-blue-500">
          <div className="flex items-start justify-between">
            <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <Badge variant="info" size="md">
              <Activity className="w-3 h-3 mr-1" />
              Efficiency
            </Badge>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">Avg. Turnaround</p>
            <p className="text-3xl font-bold text-gray-900">
              {avgTurnaround.toFixed(1)} <span className="text-lg font-normal">days</span>
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Check-in to lot exit
            </p>
          </div>
        </Card>
      </div>
      
      {/* Combined Revenue Summary */}
      <Card className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Combined Revenue</h3>
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl p-6 text-white">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-slate-400 text-sm">Garage Revenue</p>
              <p className="text-2xl font-bold text-orange-400">
                ${garageRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="text-center border-x border-slate-700">
              <p className="text-slate-400 text-sm">Stand Revenue</p>
              <p className="text-2xl font-bold text-purple-400">
                ${standRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="text-center">
              <p className="text-slate-400 text-sm">Total Revenue</p>
              <p className="text-2xl font-bold text-green-400">
                ${(garageRevenue + standRevenue).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pipeline Overview */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Vehicle Pipeline</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <span className="text-gray-700">Under Maintenance</span>
              </div>
              <span className="text-xl font-bold text-yellow-700">{pipeline.underMaintenance}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <span className="text-gray-700">Pending Transfer</span>
              </div>
              <span className="text-xl font-bold text-blue-700">{pipeline.pendingTransfer}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                <span className="text-gray-700">Active on Stand</span>
              </div>
              <span className="text-xl font-bold text-purple-700">{pipeline.activeOnStand}</span>
            </div>
            
            <div className="border-t pt-4 mt-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-gray-900">Total Active Vehicles</span>
                <span className="text-2xl font-bold text-gray-900">{pipeline.totalActive}</span>
              </div>
            </div>
          </div>
        </Card>
        
        {/* 30-Day Activity */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Last 30 Days Activity</h3>
          
          <div className="space-y-4">
            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-medium">Garage Jobs Completed</span>
                <Badge variant="warning">{recentActivity.garageCount} jobs</Badge>
              </div>
              <p className="text-2xl font-bold text-orange-700">
                ${recentActivity.garageRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
            
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-700 font-medium">Vehicle Sales</span>
                <Badge variant="purple">{recentActivity.salesCount} sales</Badge>
              </div>
              <p className="text-2xl font-bold text-purple-700">
                ${recentActivity.salesRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
            
            <div className="border-t pt-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-gray-900">30-Day Revenue</span>
                <span className="text-2xl font-bold text-green-600">
                  ${(recentActivity.garageRevenue + recentActivity.salesRevenue).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
