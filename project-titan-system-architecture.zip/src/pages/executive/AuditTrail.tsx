import { useState, useMemo } from 'react';
import { FileText, Search, Filter, Shield, Clock } from 'lucide-react';
import { useData } from '../../store/DataContext';
import { Card } from '../../components/ui/Card';
import { Input } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { PageHeader } from '../../components/layout/PageHeader';
import { format } from 'date-fns';

export function AuditTrail() {
  const { auditTrail, profiles } = useData();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [tableFilter, setTableFilter] = useState<string>('all');
  
  // Get unique values for filters
  const actionTypes = useMemo(() => {
    return [...new Set(auditTrail.map(a => a.action_type))];
  }, [auditTrail]);
  
  const tableNames = useMemo(() => {
    return [...new Set(auditTrail.map(a => a.table_name))];
  }, [auditTrail]);
  
  // Filter audit entries
  const filteredEntries = useMemo(() => {
    return auditTrail.filter(entry => {
      if (actionFilter !== 'all' && entry.action_type !== actionFilter) return false;
      if (tableFilter !== 'all' && entry.table_name !== tableFilter) return false;
      
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const user = profiles.find(p => p.id === entry.user_id);
        return (
          entry.record_id.toLowerCase().includes(query) ||
          entry.action_type.toLowerCase().includes(query) ||
          entry.table_name.toLowerCase().includes(query) ||
          (user?.email.toLowerCase().includes(query) ?? false)
        );
      }
      
      return true;
    });
  }, [auditTrail, searchQuery, actionFilter, tableFilter, profiles]);
  
  const getActionBadgeVariant = (action: string): 'success' | 'info' | 'warning' | 'danger' => {
    switch (action) {
      case 'INSERT': return 'success';
      case 'UPDATE': return 'info';
      case 'DELETE': return 'danger';
      default: return 'warning';
    }
  };
  
  const getUserEmail = (userId: string): string => {
    return profiles.find(p => p.id === userId)?.email || 'Unknown User';
  };

  return (
    <div>
      <PageHeader 
        title="System Audit Trail"
        subtitle="Immutable record of all system operations"
      />
      
      {/* Info Banner */}
      <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-3">
        <Shield className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-amber-800">Immutable Audit Log</h3>
          <p className="text-sm text-amber-700">
            This audit trail is read-only and cannot be modified, edited, or deleted. 
            All system operations are automatically recorded for compliance and governance.
          </p>
        </div>
      </div>
      
      {/* Filters */}
      <Card className="mb-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by record ID, action, table, or user..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <div className="flex gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={actionFilter}
                onChange={(e) => setActionFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Actions</option>
                {actionTypes.map(action => (
                  <option key={action} value={action}>{action}</option>
                ))}
              </select>
            </div>
            
            <select
              value={tableFilter}
              onChange={(e) => setTableFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">All Tables</option>
              {tableNames.map(table => (
                <option key={table} value={table}>{table}</option>
              ))}
            </select>
          </div>
        </div>
      </Card>
      
      {/* Audit Table */}
      <Card padding="none">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">
                  <Clock className="w-4 h-4 inline mr-2" />
                  Timestamp
                </th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">User</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Action</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Table</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Record ID</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Changes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredEntries.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>No audit entries found matching your criteria</p>
                  </td>
                </tr>
              ) : (
                filteredEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50">
                    <td className="py-4 px-6">
                      <div className="text-sm font-medium text-gray-900">
                        {format(new Date(entry.timestamp), 'PP')}
                      </div>
                      <div className="text-xs text-gray-500">
                        {format(new Date(entry.timestamp), 'pp')}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm text-gray-900">
                        {getUserEmail(entry.user_id)}
                      </div>
                      <code className="text-xs text-gray-400">
                        {entry.user_id.slice(0, 8)}...
                      </code>
                    </td>
                    <td className="py-4 px-6">
                      <Badge variant={getActionBadgeVariant(entry.action_type)}>
                        {entry.action_type}
                      </Badge>
                    </td>
                    <td className="py-4 px-6">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                        {entry.table_name}
                      </code>
                    </td>
                    <td className="py-4 px-6">
                      <code className="text-xs text-gray-600">
                        {entry.record_id.slice(0, 8)}...
                      </code>
                    </td>
                    <td className="py-4 px-6">
                      <div className="max-w-xs space-y-1">
                        {entry.old_value && (
                          <div className="text-xs">
                            <span className="text-red-600 font-medium">Old: </span>
                            <code className="bg-red-50 px-1 rounded">
                              {JSON.stringify(entry.old_value).slice(0, 40)}...
                            </code>
                          </div>
                        )}
                        {entry.new_value && (
                          <div className="text-xs">
                            <span className="text-green-600 font-medium">New: </span>
                            <code className="bg-green-50 px-1 rounded">
                              {JSON.stringify(entry.new_value).slice(0, 40)}...
                            </code>
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        
        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
          <p className="text-sm text-gray-500">
            Showing {filteredEntries.length} of {auditTrail.length} entries
          </p>
          <p className="text-xs text-gray-400">
            <Shield className="w-3 h-3 inline mr-1" />
            Read-only access • No modifications permitted
          </p>
        </div>
      </Card>
    </div>
  );
}
