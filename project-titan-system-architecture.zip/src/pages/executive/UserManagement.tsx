import { useState } from 'react';
import { Users, Shield, UserCog, Check, AlertCircle } from 'lucide-react';
import { useData } from '../../store/DataContext';
import { useAuth } from '../../store/AuthContext';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Select } from '../../components/ui/Select';
import { PageHeader } from '../../components/layout/PageHeader';
import { format } from 'date-fns';
import type { Profile, UserRole } from '../../types';

export function UserManagement() {
  const { profiles, updateProfileRole } = useData();
  const { user: currentUser } = useAuth();
  
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [newRole, setNewRole] = useState<UserRole>('manager');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const handleOpenRoleModal = (profile: Profile) => {
    setSelectedProfile(profile);
    setNewRole(profile.role);
    setSuccessMessage('');
  };
  
  const handleUpdateRole = async () => {
    if (!selectedProfile || selectedProfile.role === newRole) return;
    
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    updateProfileRole(selectedProfile.id, newRole);
    setSuccessMessage(`Role updated to ${newRole} successfully`);
    
    setIsProcessing(false);
    
    // Close modal after delay
    setTimeout(() => {
      setSelectedProfile(null);
      setSuccessMessage('');
    }, 1500);
  };
  
  const getRoleBadgeVariant = (role: UserRole): 'info' | 'purple' => {
    return role === 'management' ? 'purple' : 'info';
  };

  return (
    <div>
      <PageHeader 
        title="User Management"
        subtitle="Manage system user roles and access permissions"
      />
      
      {/* Info Banner */}
      <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-3">
        <Shield className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-blue-800">Role-Based Access Control</h3>
          <p className="text-sm text-blue-700">
            <strong>Manager</strong> role: Access to Operations Hub (vehicle intake, garage, car stand).
            <br />
            <strong>Management</strong> role: Access to Executive Hub (dashboards, audit trail, user management).
          </p>
        </div>
      </div>
      
      {/* User Grid */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">User</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Role</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Access Level</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-600">Last Updated</th>
                <th className="text-right py-4 px-6 text-sm font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {profiles.map((profile) => (
                <tr key={profile.id} className="hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white font-semibold">
                        {profile.email.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{profile.email}</p>
                        <code className="text-xs text-gray-400">{profile.id.slice(0, 8)}...</code>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <Badge variant={getRoleBadgeVariant(profile.role)} size="md">
                      {profile.role === 'management' ? (
                        <Shield className="w-3 h-3 mr-1" />
                      ) : (
                        <UserCog className="w-3 h-3 mr-1" />
                      )}
                      {profile.role.charAt(0).toUpperCase() + profile.role.slice(1)}
                    </Badge>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-600">
                      {profile.role === 'management' ? 'Executive Hub' : 'Operations Hub'}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-500">
                      {format(new Date(profile.updated_at), 'PP')}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    {profile.id === currentUser?.id ? (
                      <span className="text-sm text-gray-400 italic">Current User</span>
                    ) : (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleOpenRoleModal(profile)}
                      >
                        <UserCog className="w-4 h-4 mr-1" />
                        Change Role
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Summary Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-500">
              <Users className="w-4 h-4 inline mr-1" />
              {profiles.length} total users
            </span>
            <span className="text-sm text-gray-500">
              •
            </span>
            <span className="text-sm text-gray-500">
              {profiles.filter(p => p.role === 'manager').length} managers
            </span>
            <span className="text-sm text-gray-500">
              •
            </span>
            <span className="text-sm text-gray-500">
              {profiles.filter(p => p.role === 'management').length} executives
            </span>
          </div>
        </div>
      </Card>
      
      {/* Role Update Modal */}
      <Modal
        isOpen={!!selectedProfile}
        onClose={() => setSelectedProfile(null)}
        title="Update User Role"
        size="md"
      >
        {selectedProfile && (
          <div className="space-y-4">
            {successMessage ? (
              <div className="text-center py-6">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-lg font-medium text-gray-900">{successMessage}</p>
              </div>
            ) : (
              <>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white font-bold text-lg">
                      {selectedProfile.email.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{selectedProfile.email}</p>
                      <p className="text-sm text-gray-500">
                        Current role: <span className="font-medium">{selectedProfile.role}</span>
                      </p>
                    </div>
                  </div>
                </div>
                
                <Select
                  label="New Role"
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as UserRole)}
                  options={[
                    { value: 'manager', label: 'Manager (Operations Hub)' },
                    { value: 'management', label: 'Management (Executive Hub)' },
                  ]}
                />
                
                {selectedProfile.role !== newRole && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-700">
                      <p className="font-medium">Role Change Warning</p>
                      <p>
                        Changing from <strong>{selectedProfile.role}</strong> to <strong>{newRole}</strong> will 
                        {newRole === 'management' 
                          ? ' grant executive access and restrict operations access.'
                          : ' grant operations access and restrict executive access.'
                        }
                      </p>
                    </div>
                  </div>
                )}
                
                <div className="flex gap-3 mt-6">
                  <Button
                    variant="secondary"
                    className="flex-1"
                    onClick={() => setSelectedProfile(null)}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="primary"
                    className="flex-1"
                    onClick={handleUpdateRole}
                    isLoading={isProcessing}
                    disabled={selectedProfile.role === newRole}
                  >
                    Update Role
                  </Button>
                </div>
              </>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
